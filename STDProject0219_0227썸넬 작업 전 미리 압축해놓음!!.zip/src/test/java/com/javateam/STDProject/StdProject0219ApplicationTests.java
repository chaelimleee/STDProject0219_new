package com.javateam.STDProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StdProject0219ApplicationTests {

	@Test
	void contextLoads() {
	}

}
